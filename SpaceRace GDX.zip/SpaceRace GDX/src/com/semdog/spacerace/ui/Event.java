package com.semdog.spacerace.ui;

public interface Event {
	public void execute();
}
